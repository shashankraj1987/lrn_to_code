# PVG.Obfuscated
Obfuscated Python Code for Hacking and Poke the Dots games, PVG MOOC (Coursera)

To grab a copy (aka clone repo):

  git clone git@github.com:paullu-ualberta/PVG.Obfuscated.git

To run from command-line (Mac, Linux):

  1.  python3 Hacking1.py

  2.  python3 Hacking2.py

  3.  python3 Hacking3.py

  4.  python3 Hacking4.py

  5.  python3 Hacking5.py

  6.  python3 Hacking6.py

  7.  python3 Hacking7.py

  8.  python3 Poke1.py

  9.  python3 Poke2.py

  10. python3 Poke3.py

  11. python3 Poke4.py

  12. python3 Poke5.py


To run from command-line (Windows):
  1.  python Hacking1.py

  2.  python Hacking2.py

  3.  python Hacking3.py

  4.  python Hacking4.py

  5.  python Hacking5.py

  6.  python Hacking6.py

  7.  python Hacking7.py

  8.  python Poke1.py

  9.  python Poke2.py

  10. python Poke3.py

  11. python Poke4.py

  12. python Poke5.py